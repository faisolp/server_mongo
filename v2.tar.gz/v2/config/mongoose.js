var mongoose =require ("mongoose");

//process.env.NODE_ENV="production";
//const uri ="mongodb://localhost/Fortigate";
module.exports  = function () {
    var config = require("./config");
    //if(process.env.NODE_ENV !="production")
    //     mongoose.set("debug",true);
   // else
    mongoose.set("debug",false);
    mongoose.Promise =Promise;
    var db= mongoose.connect(config.mongoUri);
    //db.db("iotdb");
   // mongoose.db("iotdb");
    
    //======= Data Modele======================
    require("../app/modeles/mc_log.modele");
  
    //=========================================
    

    return db;
};