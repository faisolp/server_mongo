module.exports= {
    mongoUri:"mongodb://mongo:27017/iotdb",
    sessionSecret:"develop_secret_key"
};
