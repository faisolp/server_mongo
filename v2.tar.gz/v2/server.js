process.env.NODE_ENV=process.env.NODE_ENV|| "development"; //"production";//

const express = require('express');
const PORT = 4000;
const app = express() ;




var mongoose =require( "./config/mongoose");

var db=mongoose();

require('./app/rootes/index.roote')(app);


app.listen(PORT, function(){
    console.log('Your node js server is running on PORT:',PORT);
});
