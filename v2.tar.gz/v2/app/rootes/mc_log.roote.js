module.exports=function(app) {
    var mc_log =require("../controllers/mc_log.controller");
    //app.post("/login",user.login);
   // app.post("/logout",user.logout);

    app.route("/api/mc_log/record/v1.0")
        .get( function(req, res) {
            mc_log.record(req,function(err){
                if(err) {
                    console.log(`server got error: ${JSON.stringify(err)} `);     
                } else 
                res.json({"result":"ok"});
            });
        
           
        });
            
        app.route("/api/mc_log/read/v1.0")
        .get(function(req, res) {
                mc_log.read(req,res,function(err){
                    console.log(`server got error: ${JSON.stringify(err)}`);  
                    } 
                );

            }
        )
       // .get(mc_log.list());

       
    /*app.route("/api/mc_log/read/v1.0")
        .get( function(req, res) {
            
            mc_log.read(req,res,function(err){
                if(err) {
                    console.log(`server got error: ${JSON.stringify(err)} from ${rinfo.address}:${rinfo.port}`);     
                } 
            });
           
           
        });*/
            
          
   
        
}