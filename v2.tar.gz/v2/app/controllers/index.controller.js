exports.render =function (req,res){
    res.json({"hello API IoT": "world"});
};

