module.exports=function(_query){
    var _data ={};
  

    for (const key in _query) {

        console.log(key, _query[key]);
        switch(key) {
            case "datetime" :
                _data[key]=new Date(_query[key]);
                break;
            default:
                _data[key]=_query[key];
        }
      }
  
   
   return _data;
  }