var mongoose=require("mongoose");
var Schema=mongoose.Schema;

var mc_logSchema = new Schema({

    createdDate:{type:Date,default:Date.now,index:true},
    datetime:{type:Date,default:Date.now,index:true},
    mcid:{type:String,index:true},
    locid:{type:String,index:true},
  
 //   time:String,
  
    //======================

    P1: Number,
    P2: Number,
    P3: Number,
    P4: Number,
    P5: Number,
    P6: Number,
    P7: Number,
    P8: Number,
    P9: Number,
    P10:Number,
   
   
},  { capped: { size: 1000000000, max: 10368000 } }); //1Gbyte

mongoose.model("mc_log",mc_logSchema);
