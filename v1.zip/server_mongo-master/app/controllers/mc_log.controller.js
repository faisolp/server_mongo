var mc_log = require("mongoose").model("mc_log");
var convertPacket =require("../codes/mc_log_convertPacket.code");
var round = require('mongo-round');
  
//var mapHostname = new Map();
function isEmpty(obj) {
    for(var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
    }
    return true;
}
function Date2Str(_date){
    //var today = new Date();
    //today
    var dd = _date.getDay();
    var mm = _date.getMonth();
    var yyyy = _date.getFullYear();

    if (dd < 10) {
    dd = '0' + dd;
    }

    if (mm < 10) {
    mm = '0' + mm;
    }

    var today = yyyy + '-' + mm + '-' + dd;
    return  today
}
//------------------------------------------------------------------


// record
exports.record =function(_req,next) {
   // var convertPacket =require("../code/mc_log_convertPacket.code");
   
     var _data= convertPacket(_req.query); 
    if(! isEmpty( _data) && _data.mcid!="" && !(_data.mcid === undefined)){
        var _mc_log = new mc_log(_data);  
        _mc_log.save(function(err){
            if(err)
                return next(err);
            else  {
                return next(null);
             //res.json({"result":"ok"});
            }
        });
    }

}

 
// read
 exports.read = function (_req,_res, next) {
    var isFrist=true;
    var strGroupDate= "%Y-%m-%dT%H:%M:%S";

    if(!(_req.query.GroupDate === undefined)){
        switch (_req.query.GroupDate) {
            case "min" :
            strGroupDate= "%Y-%m-%dT%H:%M:00";
                break;
            case "hour" :
            strGroupDate= "%Y-%m-%dT%H:00:00";
                break;
            case "day" :
            strGroupDate= "%Y-%m-%dT00:00:00";
                break;
            default :
            strGroupDate= "%Y-%m-%dT%H:%M:%S";

        }
    }
    var toDate = new Date();
    var formDate =new Date(new Date().setDate(new Date().getDate()-1))

   

    if(_req.query.toDate!="" && !(_req.query.toDate === undefined))
        toDate= new Date(_req.query.toDate);   
    if(_req.query.formDate!="" && !(_req.query.formDate === undefined))
        formDate= new Date(_req.query.formDate);

    var locid = _req.query.locid!="" && !(_req.query.locid === undefined) ?_req.query.locid :'';
   
       
    
    var stream=mc_log.aggregate([
      {$match:{ datetime: { $gte: formDate   , $lt: toDate } }},
      {
        $group:{
          _id : { 
            mcid:"$mcid",
            datetime:{ $toDate: { $dateToString: { format: strGroupDate, date: "$datetime" } } },  
           //datetime: { $dateToString: { format: strGroupDate, date: "$createdDate" } }  ,  
 //           locid:"$locid",
          },
          
          P1:{$avg:"$P1"},
          P2:{$avg:"$P2"},
          P3:{$avg:"$P3"},
          P4:{$avg:"$P4"},
          P5:{$avg:"$P5"},
          P6:{$avg:"$P6"},
          P7:{$avg:"$P7"},
          P8:{$avg:"$P8"},
          P9:{$avg:"$P9"},
          P10:{$avg:"$P10"}
         
        }
      }
    ])
    .exec(function (err, record){
      if (err) {
          return next(err);
      } else {
          _res.json(record);
      }
    });
}

   