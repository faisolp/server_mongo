module.exports= {
    mongoUri:"mongodb://172.18.1.124/iotdb",
    sessionSecret:"production_secret_key"
}