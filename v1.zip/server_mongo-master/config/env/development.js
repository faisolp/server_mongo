module.exports= {
    mongoUri:"mongodb://localhost",
    sessionSecret:"develop_secret_key"
};